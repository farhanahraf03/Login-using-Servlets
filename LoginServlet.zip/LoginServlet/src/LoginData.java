import java.sql.*;

public class LoginData {

	public static boolean validate(String username,String password)
	{
		boolean status = false;
		try
		{
			String JDBC_DRIVER = "com.mysql.jdbc.Driver";
			String DB_URL = "jdbc:mysql://localhost/farhan_test"; //farhan_test is the database name
		
			String USER = "root";
			String PASS = "";
			
			Class.forName(JDBC_DRIVER);
			Connection conn = DriverManager.getConnection(DB_URL,USER,PASS);
		
			//login is the table name
			PreparedStatement ps = conn.prepareStatement("select * from login where username = ? and password = ?");
			ps.setString(1,username);
			ps.setString(2, password);
			
			ResultSet rs = ps.executeQuery();
			status = rs.next();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return status;
	}
}
