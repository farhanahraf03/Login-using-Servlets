import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class FirstServlet extends HttpServlet{

	public void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException
	{
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String u = request.getParameter("username");
		String p = request.getParameter("password");
		
		if(LoginData.validate(u,p))
		{
			RequestDispatcher rd = request.getRequestDispatcher("servlet2");
			rd.forward(request,response); 
		}
		
		else
		{
			out.println("<h3>Wrong username or Password</h3><br>");
			RequestDispatcher rd = request.getRequestDispatcher("index.html");
			rd.include(request, response);
		}
		
		out.close();
	}
}
